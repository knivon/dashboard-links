# source: https://www.zabbix.com/documentation/3.4/manual/api & https://docs.python-requests.org/en/master/
# api endpoint: https://zabbix.backblaze.com/zabbix/api_jsonrpc.php
# might use postman
import json
from pprint import pprint

import requests

#IGNORE THIS, I WAS TESTING SOMETHING OUT

# Accessing data from end point
ZABBIX_API_URL = 'https://zabbix.backblaze.com/zabbix/api_jsonrpc.php'
USER = "admin"
PASS = "password"


# In order to authenticate

# grabs data
payload = {
    "jsonrpc": "2.0",
    "method": "user.login",
    "params": {
        "user": USER,
        "password": PASS
    },
    "id": 1,
    "auth": None,
}
# submitted as endpoint for postr and data attribute
# r = requests.post(ZABBIX_API_URL, data = payload)

header = {
    'Content-type': 'application/json'
}

res = requests.post(ZABBIX_API_URL, data = json.dump(payload), header= header)


# Trying below for NOW
# res  = requests.post(ZABBIX_API_URL, data=json.dumps(json), header=header)
res = res.json()
print ("user.login response")
pprint(res)


# Hosting
json = {
    "jsonrpc": "2.0",
    "method": "host.get",
    "params": {
        "output": [
            "hostid",
            "host"
        ],
        "selectInterfaces": [
            "interfaceid",
            "ip"
        ]
    },
    "id": 2,
    "auth": res['result']
}

# Trying below for NOW
res2  = requests.post(ZABBIX_API_URL, data=json.dumps(json), header=header)
res2 = res2.json()
print ("user.login response")
pprint(res2)
