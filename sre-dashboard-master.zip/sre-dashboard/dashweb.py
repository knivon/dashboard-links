from pprint import pprint

from flask import Flask, redirect, url_for, render_template, request
import requests
import json
app = Flask(__name__)

@app.route("/home")
@app.route("/")
def home(): #route
    return render_template("index.html")

# @app.route("/login", methods=["POST", "GET"])
# def login():
#     return render_template()

@app.route("/servers")
def servers(): #route
    return render_template("new.html")

@app.route("/bandwidth")
def bandwidth(): #route
    return render_template("dashboards/bandwidth.html")

@app.route("/s3uploads")
def uploads(): #route
    return render_template("dashboards/s3uploads.html")

@app.route("/vaultdeletion")
def vaultdeletion(): #route
    return render_template("dashboards/vaultdeletion.html")

@app.route("/downloadstats")
def downloadstats(): #route
    return render_template("dashboards/downloadstats.html")

@app.route("/zabbix")
def zabbix(): #route
    return render_template("dashboards/zabbix.html")

@app.route("/notification")
def notification(): #route
    return render_template("dashboards/notifications.html")

@app.route("/testing", methods=['GET','POST'])
def index():
    # req = requests.get('https://zabbix.backblaze.com/zabbix/api_jsonrpc.php')
    # print(req.content)

    # Accessing data from end point
    ZABBIX_API_URL = 'https://zabbix.backblaze.com/zabbix/api_jsonrpc.php'
    USER = "admin"
    PASS = "password"


    # In order to authenticate

    # grabs data
    payload = {
        "jsonrpc": "2.0",
        "method": "user.login",
        "params": {
            "user": "knivon",
            "password": "Sugarnivon123@"
        },
        "id": 1,
        "auth": None,
    }
    # submitted as endpoint for postr and data attribute
    # r = requests.post(ZABBIX_API_URL, data = payload)

    header = {
        'Content-type': 'application/json'
    }

    res = requests.post(ZABBIX_API_URL, data=json.dumps(payload), headers=header)


    # Trying below for NOW
    # res  = requests.post(ZABBIX_API_URL, data=json.dumps(json), header=header)
    res = res.json()
    print("user.login response")
    pprint(res)


    # Hosting
    payload = {
        "jsonrpc": "2.0",
        "method": "host.get",
        "params": {
            "output": [
                "hostid",
                "host"
            ],
            "selectInterfaces": [
                "interfaceid",
                "ip"
            ]
        },
        "id": 2,
        "auth": res['result']
    }
    res2 = requests.post(ZABBIX_API_URL, data=json.dumps(payload), headers=header)
    res2 = res2.json()
    print("host.get response")
    pprint(res2)
    return 'hello'


# # grabs data
# payload = {
#     "jsonrpc": "2.0",
#     "method": "user.login",
#     "params": {
#         "user": USER,
#         "password": PASS
#     },
#     "id": 1,
#     "auth": None,
# }

# # all for logging in -main idea: GET AND POST INFO
# @app.route("/login", methods=["POST", "GET"])
# def login():
#     if request.method == "POST":
#         user = request.form["nm"]
#         return redirect(url_for("user", usr=user))
#     else:
#         return render_template("new.html")
#
# @app.route("/<usr>")
# def user(usr):
#     return f"<h1>{usr}</h1>"

if __name__ == "__main__":
    app.run(debug=True) #no need to rerun