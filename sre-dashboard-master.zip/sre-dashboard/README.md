Requires Python 3.7+
Bootstrap used: https://www.creative-tim.com/product/material-dashboard-flask

Run application within the virtual environment: python "dashweb.py"